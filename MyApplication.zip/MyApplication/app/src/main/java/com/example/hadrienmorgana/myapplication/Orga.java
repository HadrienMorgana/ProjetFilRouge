package com.example.hadrienmorgana.myapplication;

/**
 * Created by hadrienmorgana on 04/06/2018.
 */

public class Orga {
    int id;
    String orgaName;

    public Orga(int i, String orgaName) {
        super();
        this.id = i;
        this.orgaName = orgaName;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getOrgaName() {
        return orgaName;
    }
    public void setOrgaName(String orgaName) {
        this.orgaName = orgaName;
    }
}
