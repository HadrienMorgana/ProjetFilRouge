package com.example.hadrienmorgana.myapplication;

/**
 * Created by hadrienmorgana on 04/06/2018.
 */

public class Group {
    int id;
    String groupName;

    public Group(int i, String groupName) {
        super();
        this.id = i;
        this.groupName = groupName;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getGroupName() {
        return groupName;
    }
    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
}
