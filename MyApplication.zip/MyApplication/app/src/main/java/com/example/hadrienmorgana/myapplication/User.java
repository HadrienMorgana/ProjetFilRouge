package com.example.hadrienmorgana.myapplication;

/**
 * Created by hadrienmorgana on 03/06/2018.
 */

public class User {
    int id;
    String userName;

    public User(int i, String userName) {
        super();
        this.id = i;
        this.userName = userName;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
}
